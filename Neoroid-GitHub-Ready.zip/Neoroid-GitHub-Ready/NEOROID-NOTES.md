# Neoroid build starter

This is the Kvaesitso 1.41.0 source project with a GitHub Actions workflow added.

## Build a test APK

1. Put the contents of this folder in a GitHub repository named `Neoroid`.
2. Open the repository's **Actions** tab.
3. Choose **Build Neoroid APK** and press **Run workflow**.
4. When it finishes, open the run and download `neoroid-test-apk` under Artifacts.

This first workflow builds the unmodified launcher as a test. It does **not** yet include the Neoroid branding, blue theme, download welcome screen, or default-launcher prompt. Those changes must be made and tested before calling the result Neoroid.

The project wrapper asks for Gradle 9.5.0. GitHub's runner downloads it during the build. Java 21 is selected for this project.

Keep the original LICENSE.txt and notices when modifying or sharing this project.
